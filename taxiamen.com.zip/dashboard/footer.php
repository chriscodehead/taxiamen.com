<div class="nk-footer nk-footer-fluid">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright"> &copy; <?php $d = date('Y');
                                                        print @$d; ?> <?php print $siteName; ?>. All Right Reserved.
            </div>
            <div class="nk-footer-links">
                <ul class="nav nav-sm">
                    <li class="nav-item"><a target="_blank" class="nav-link" href="../terms">Terms</a></li>
                    <li class="nav-item"><a target="_blank" class="nav-link" href="../disclaimer">Disclaimer</a></li>
                    <li class="nav-item"><a target="_blank" class="nav-link" href="../contact">Help</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<script src="assets/js/bundle.js?ver=2.2.0"></script>
<script src="assets/js/scripts.js?ver=2.2.0"></script>
<script src="assets/js/charts/chart-crypto.js?ver=2.2.0"></script>
<script src="toast/jquery.toast.js"></script>
<script src="toast/toast-functions.js"></script>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>
</body>

</html>