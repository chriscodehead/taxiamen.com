<?php require_once('../library.php'); ?>
<?php $cal->updatePaymentStatusNowpayments(); ?>