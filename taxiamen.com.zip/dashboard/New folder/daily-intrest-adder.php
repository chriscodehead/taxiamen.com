<?php require_once('../library.php'); ?>
<?php 

		$cal->add_interest_weeklyLB();
		$cal->weekly_ConunterLB();

		$cal->add_interest_weeklyLC();
		$cal->weekly_ConunterLC();

?>